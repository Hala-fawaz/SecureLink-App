import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class ManagePostsScreen extends StatefulWidget {
  const ManagePostsScreen({super.key});

  @override
  State<ManagePostsScreen> createState() => _ManagePostsScreenState();
}

class _ManagePostsScreenState extends State<ManagePostsScreen> {

  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  final titleController = TextEditingController();
  final contentController = TextEditingController();

  File? pickedImage;
  bool isLoading = false;

  final ImagePicker picker = ImagePicker();

  /// ================= اختيار صورة =================
  Future<void> pickImage() async {
    final image = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 60,
    );

    if (image != null) {
      setState(() {
        pickedImage = File(image.path);
      });
    }
  }

  /// ================= رفع الصورة =================
  Future<String?> uploadImage(File image) async {
    try {
      final ref = FirebaseStorage.instance
          .ref()
          .child('posts/${DateTime.now().millisecondsSinceEpoch}.jpg');

      await ref.putFile(image);

      return await ref.getDownloadURL();

    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("فشل رفع الصورة")),
      );
      return null;
    }
  }

  /// ================= حذف =================
  Future<void> deletePost(DocumentSnapshot doc) async {

    try {
      if (doc['imageUrl'] != "") {
        await FirebaseStorage.instance
            .refFromURL(doc['imageUrl'])
            .delete();
      }
    } catch (_) {}

    await firestore.collection('posts').doc(doc.id).delete();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("تم حذف المنشور")),
    );
  }

  /// ================= الفورم =================
  void openForm({DocumentSnapshot? doc}) {

    if (doc != null) {
      titleController.text = doc['title'];
      contentController.text = doc['content'];
      pickedImage = null;
    } else {
      titleController.clear();
      contentController.clear();
      pickedImage = null;
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            left: 20,
            right: 20,
            top: 25,
            bottom: MediaQuery.of(context).viewInsets.bottom + 20,
          ),
          child: SingleChildScrollView(
            child: Column(
              children: [

                Text(
                  doc == null ? "إضافة منشور" : "تعديل المنشور",
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 20),

                TextField(
                  controller: titleController,
                  decoration: const InputDecoration(
                    labelText: "العنوان",
                    prefixIcon: Icon(Icons.title),
                  ),
                ),

                const SizedBox(height: 15),

                TextField(
                  controller: contentController,
                  maxLines: 5,
                  decoration: const InputDecoration(
                    labelText: "المحتوى",
                    prefixIcon: Icon(Icons.notes),
                  ),
                ),

                const SizedBox(height: 15),

                /// صورة
                GestureDetector(
                  onTap: pickImage,
                  child: Container(
                    height: 160,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: pickedImage != null
                        ? ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: Image.file(
                        pickedImage!,
                        fit: BoxFit.cover,
                      ),
                    )
                        : doc != null && doc['imageUrl'] != ""
                        ? ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: Image.network(
                        doc['imageUrl'],
                        fit: BoxFit.cover,
                        loadingBuilder: (context, child, progress) {
                          if (progress == null) return child;
                          return const Center(
                              child: CircularProgressIndicator());
                        },
                        errorBuilder: (_, __, ___) {
                          return _imagePlaceholder();
                        },
                      ),
                    )
                        : _imagePlaceholder(),
                  ),
                ),

                const SizedBox(height: 25),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: isLoading ? null : () async {

                      if (titleController.text.isEmpty ||
                          contentController.text.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("أدخل جميع الحقول")),
                        );
                        return;
                      }

                      setState(() => isLoading = true);

                      String? imageUrl =
                      doc != null ? doc['imageUrl'] : null;

                      if (pickedImage != null) {
                        imageUrl = await uploadImage(pickedImage!);
                      }

                      if (doc == null) {
                        await firestore.collection('posts').add({
                          "title": titleController.text,
                          "content": contentController.text,
                          "imageUrl": imageUrl ?? "",
                          "createdAt": Timestamp.now(),
                        });
                      } else {
                        await firestore.collection('posts')
                            .doc(doc.id)
                            .update({
                          "title": titleController.text,
                          "content": contentController.text,
                          "imageUrl": imageUrl ?? "",
                        });
                      }

                      Navigator.pop(context);
                      setState(() => isLoading = false);

                    },
                    child: isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text(doc == null ? "إضافة" : "تحديث"),
                  ),
                )

              ],
            ),
          ),
        );
      },
    );
  }

  /// ================= Placeholder =================
  Widget _imagePlaceholder() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(15),
      ),
      child: const Center(
        child: Icon(Icons.image, size: 50, color: Colors.grey),
      ),
    );
  }

  /// ================= الصفحة =================
  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: const Text("إدارة منشورات التوعية"),
      ),

      floatingActionButton: FloatingActionButton(
        onPressed: () => openForm(),
        child: const Icon(Icons.add),
      ),

      body: StreamBuilder(
        stream: firestore
            .collection('posts')
            .orderBy('createdAt', descending: true)
            .snapshots(),

        builder: (context, snapshot) {

          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          var docs = snapshot.data!.docs;

          if (docs.isEmpty) {
            return const Center(child: Text("لا توجد منشورات"));
          }

          return ListView.builder(
            padding: const EdgeInsets.all(15),
            itemCount: docs.length,
            itemBuilder: (context, index) {

              var doc = docs[index];

              return Container(
                margin: const EdgeInsets.only(bottom: 15),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0,5),
                    )
                  ],
                ),

                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    /// الصورة (مهم جداً AspectRatio)
                    if (doc['imageUrl'] != "")
                      ClipRRect(
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(20),
                        ),
                        child: AspectRatio(
                          aspectRatio: 16/9,
                          child: Image.network(
                            doc['imageUrl'],
                            fit: BoxFit.cover,
                            loadingBuilder: (context, child, progress) {
                              if (progress == null) return child;
                              return const Center(
                                  child: CircularProgressIndicator());
                            },
                            errorBuilder: (_, __, ___) =>
                                _imagePlaceholder(),
                          ),
                        ),
                      ),

                    Padding(
                      padding: const EdgeInsets.all(15),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                          Row(
                            children: [

                              Expanded(
                                child: Text(
                                  doc['title'],
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),

                              PopupMenuButton(
                                itemBuilder: (context) => [
                                  const PopupMenuItem(
                                    value: "edit",
                                    child: Text("تعديل"),
                                  ),
                                  const PopupMenuItem(
                                    value: "delete",
                                    child: Text("حذف"),
                                  ),
                                ],
                                onSelected: (value) {
                                  if (value == "edit") {
                                    openForm(doc: doc);
                                  } else {
                                    deletePost(doc);
                                  }
                                },
                              )

                            ],
                          ),

                          const SizedBox(height: 8),

                          Text(
                            doc['content'],
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Colors.grey),
                          ),

                        ],
                      ),
                    )

                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}