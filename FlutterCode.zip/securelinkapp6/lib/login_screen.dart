import 'dart:async';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'register_screen.dart';
import 'admin_home_screen.dart';
import 'user_home_screen.dart';
import 'loginadmin.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  final TextEditingController phoneController = TextEditingController();
  final TextEditingController codeController = TextEditingController();

  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  String verificationId = "";

  bool codeSent = false;
  bool isLoading = false;

  /// ✅ المؤقت
  int secondsRemaining = 60;
  Timer? timer;
  bool canResend = false;

  /// ================= بدء المؤقت =================
  void startTimer() {

    secondsRemaining = 60;
    canResend = false;

    timer?.cancel();

    timer = Timer.periodic(
      const Duration(seconds: 1),
          (timer) {

        if (secondsRemaining == 0) {

          setState(() {
            canResend = true;
          });

          timer.cancel();

        } else {

          setState(() {
            secondsRemaining--;
          });

        }

      },
    );
  }

  /// ================= إرسال كود =================
  Future<void> sendCode() async {

    String phone = phoneController.text.trim();

    if (phone.isEmpty) {

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("ادخل رقم الجوال")),
      );

      return;
    }

    if (phone.startsWith("05")) {
      phone = "+966${phone.substring(1)}";
    }

    setState(() => isLoading = true);

    await auth.verifyPhoneNumber(

      phoneNumber: phone,
      timeout: const Duration(seconds: 60),

      verificationCompleted: (PhoneAuthCredential credential) async {

        await auth.signInWithCredential(credential);

      },

      verificationFailed: (FirebaseAuthException e) {

        setState(() => isLoading = false);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              e.message ?? "فشل إرسال الكود",
            ),
          ),
        );

      },

      codeSent: (String verId, int? resendToken) {

        startTimer();

        setState(() {

          verificationId = verId;
          codeSent = true;
          isLoading = false;

        });

      },

      codeAutoRetrievalTimeout: (String verId) {

        verificationId = verId;

      },

    );

  }

  /// ================= تحقق من الكود =================
  Future<void> verifyCode() async {

    if (codeController.text.isEmpty) {

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("ادخل كود التحقق")),
      );

      return;
    }

    try {

      setState(() => isLoading = true);

      PhoneAuthCredential credential =
      PhoneAuthProvider.credential(

        verificationId: verificationId,
        smsCode: codeController.text.trim(),

      );

      UserCredential userCredential =
      await auth.signInWithCredential(credential);

      String uid = userCredential.user!.uid;

      DocumentSnapshot userDoc =
      await firestore.collection("users").doc(uid).get();

      /// إنشاء حساب تلقائي
      if (!userDoc.exists) {

        await firestore.collection("users").doc(uid).set({

          "name": "",
          "phone": userCredential.user!.phoneNumber ?? "",
          "email": "",
          "gender": "ذكر",
          "education": "بكالوريوس",
          "isAdmin": false,
          "createdAt": FieldValue.serverTimestamp(),

        });

      }

      bool isAdmin = userDoc.exists
          ? (userDoc['isAdmin'] ?? false)
          : false;

      if (isAdmin) {

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => const AdminHomeScreen(),
          ),
        );

      } else {

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => const UserHomeScreen(),
          ),
        );

      }

    } catch (e) {

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("كود غير صحيح")),
      );

    }

    setState(() => isLoading = false);

  }

  @override
  void dispose() {

    timer?.cancel();

    phoneController.dispose();
    codeController.dispose();

    super.dispose();

  }

  /// ================= UI =================
  @override
  Widget build(BuildContext context) {

    return Directionality(

      textDirection: TextDirection.rtl,

      child: Scaffold(

        body: Container(

          width: double.infinity,

          decoration: const BoxDecoration(

            gradient: LinearGradient(

              colors: [
                Color(0xFFF8FAFC),
                Color(0xFFF1F5F9),
                Color(0xFFEFF6FF),
              ],

              begin: Alignment.topLeft,
              end: Alignment.bottomRight,

            ),

          ),

          child: SafeArea(

            child: Center(

              child: SingleChildScrollView(

                padding: const EdgeInsets.symmetric(horizontal: 30),

                child: Column(

                  children: [

                    Image.asset(
                      "assets/logo.png",
                      height: 200,
                    ),

                    const SizedBox(height: 20),

                    const Text(

                      "تسجيل الدخول",

                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),

                    ),

                    const SizedBox(height: 30),

                    Container(

                      padding: const EdgeInsets.all(20),

                      decoration: BoxDecoration(

                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),

                        boxShadow: [

                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            blurRadius: 15,
                          )

                        ],

                      ),

                      child: Column(

                        children: [

                          /// رقم الجوال
                          TextField(

                            controller: phoneController,
                            keyboardType: TextInputType.phone,

                            decoration: InputDecoration(

                              labelText: "رقم الجوال (05xxxxxxxx)",
                              prefixIcon: const Icon(Icons.phone),

                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),

                            ),

                          ),

                          const SizedBox(height: 15),

                          /// كود التحقق
                          if (codeSent)
                            TextField(

                              controller: codeController,
                              keyboardType: TextInputType.number,

                              decoration: InputDecoration(

                                labelText: "كود التحقق",
                                prefixIcon: const Icon(Icons.lock),

                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),

                              ),

                            ),

                          /// المؤقت
                          if (codeSent)
                            Padding(

                              padding: const EdgeInsets.only(top: 10),

                              child: Text(

                                canResend
                                    ? "يمكنك إعادة إرسال الكود"
                                    : "إعادة الإرسال بعد $secondsRemaining ثانية",

                                style: TextStyle(

                                  color: canResend
                                      ? Colors.green
                                      : Colors.red,

                                  fontWeight: FontWeight.bold,

                                ),

                              ),

                            ),

                          const SizedBox(height: 20),

                          /// الزر
                          SizedBox(

                            width: double.infinity,
                            height: 50,

                            child: ElevatedButton(

                              onPressed: isLoading
                                  ? null
                                  : (codeSent
                                  ? verifyCode
                                  : sendCode),

                              child: isLoading

                                  ? const CircularProgressIndicator(
                                color: Colors.white,
                              )

                                  : Text(

                                codeSent
                                    ? "تأكيد الكود"
                                    : canResend
                                    ? "إعادة إرسال الكود"
                                    : "إرسال الكود",

                              ),

                            ),

                          ),

                        ],

                      ),

                    ),

                    const SizedBox(height: 20),

                    Column(

                      children: [

                        Row(

                          mainAxisAlignment: MainAxisAlignment.center,

                          children: [

                            const Text("ليس لديك حساب؟"),

                            TextButton(

                              onPressed: () {

                                Navigator.push(

                                  context,

                                  MaterialPageRoute(

                                    builder: (context) =>
                                    const RegisterScreen(),

                                  ),

                                );

                              },

                              child: const Text("إنشاء حساب"),

                            ),

                          ],

                        ),

                        const SizedBox(height: 5),

                        TextButton.icon(

                          onPressed: () {

                            Navigator.push(

                              context,

                              MaterialPageRoute(

                                builder: (context) =>
                                const LoginAdmin(),

                              ),

                            );

                          },

                          icon: const Icon(Icons.admin_panel_settings),

                          label: const Text("تسجيل دخول الأدمن"),

                        ),

                      ],

                    ),

                  ],

                ),

              ),

            ),

          ),

        ),

      ),

    );

  }

}