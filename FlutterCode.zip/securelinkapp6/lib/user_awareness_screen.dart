import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class UserAwarenessScreen extends StatelessWidget {
  const UserAwarenessScreen({super.key});

  @override
  Widget build(BuildContext context) {

    final FirebaseFirestore firestore = FirebaseFirestore.instance;

    return Directionality(
      textDirection: TextDirection.rtl,

      child: Scaffold(

        backgroundColor: const Color(0xFFF5F7FB),

        appBar: AppBar(
          title: const Text("منشورات التوعية"),
          centerTitle: true,
        ),

        body: StreamBuilder<QuerySnapshot>(

          stream: firestore
              .collection("posts")
              .orderBy("createdAt", descending: true)
              .snapshots(),

          builder: (context, snapshot) {

            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }

            if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
              return const Center(
                child: Text(
                  "لا توجد منشورات توعوية حالياً",
                  style: TextStyle(fontSize: 18),
                ),
              );
            }

            var posts = snapshot.data!.docs;

            return ListView.builder(
              padding: const EdgeInsets.all(20),
              itemCount: posts.length,
              itemBuilder: (context, index) {

                var post = posts[index];

                String title = post['title'];
                String content = post['content'];
                String image = post['imageUrl'] ?? "";

                Timestamp time = post['createdAt'];
                DateTime date = time.toDate();

                return Container(

                  margin: const EdgeInsets.only(bottom: 20),

                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.06),
                        blurRadius: 12,
                        offset: const Offset(0,5),
                      )
                    ],
                  ),

                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      /// 🔥 صورة محسنة
                      ClipRRect(
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(22),
                        ),
                        child: AspectRatio(
                          aspectRatio: 16/9,
                          child: image.isNotEmpty
                              ? Image.network(
                            image,
                            fit: BoxFit.cover,

                            /// تحميل
                            loadingBuilder: (context, child, progress) {
                              if (progress == null) return child;
                              return const Center(
                                  child: CircularProgressIndicator());
                            },

                            /// خطأ
                            errorBuilder: (_, __, ___) =>
                                _imagePlaceholder(),
                          )
                              : _imagePlaceholder(),
                        ),
                      ),

                      /// المحتوى
                      Padding(
                        padding: const EdgeInsets.all(18),

                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            /// العنوان
                            Text(
                              title,
                              style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),

                            const SizedBox(height: 10),

                            /// النص
                            Text(
                              content,
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Colors.grey,
                                height: 1.6,
                              ),
                            ),

                            const SizedBox(height: 15),

                            Row(
                              children: [

                                const Icon(
                                  Icons.calendar_today,
                                  size: 16,
                                  color: Colors.grey,
                                ),

                                const SizedBox(width: 6),

                                Text(
                                  "${date.day}/${date.month}/${date.year}",
                                  style: const TextStyle(
                                    color: Colors.grey,
                                    fontSize: 12,
                                  ),
                                ),

                                const Spacer(),

                                TextButton(
                                  onPressed: () {
                                    showPost(context, title, content, image);
                                  },
                                  child: const Text("قراءة المزيد"),
                                )

                              ],
                            )

                          ],
                        ),

                      )

                    ],
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }

  /// ================= Placeholder =================
  Widget _imagePlaceholder() {
    return Container(
      color: Colors.grey[300],
      child: const Center(
        child: Icon(Icons.image, size: 50, color: Colors.grey),
      ),
    );
  }

  /// ================= عرض المنشور =================
  void showPost(BuildContext context, String title, String content, String image) {

    showModalBottomSheet(

      context: context,
      isScrollControlled: true,

      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),

      builder: (context) {

        return Padding(

          padding: const EdgeInsets.all(20),

          child: SingleChildScrollView(

            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                /// صورة
                ClipRRect(
                  borderRadius: BorderRadius.circular(15),
                  child: AspectRatio(
                    aspectRatio: 16/9,
                    child: image.isNotEmpty
                        ? Image.network(
                      image,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) =>
                          _imagePlaceholder(),
                    )
                        : _imagePlaceholder(),
                  ),
                ),

                const SizedBox(height: 20),

                /// العنوان
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 15),

                /// المحتوى
                Text(
                  content,
                  style: const TextStyle(
                    fontSize: 16,
                    height: 1.7,
                  ),
                ),

                const SizedBox(height: 20),

              ],
            ),
          ),
        );
      },
    );
  }
}