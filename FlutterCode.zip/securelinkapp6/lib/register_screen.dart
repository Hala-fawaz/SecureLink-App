import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {

  final nameController = TextEditingController();
  final phoneController = TextEditingController();

  DateTime? birthDate;
  String? gender;
  String? education;

  final auth = FirebaseAuth.instance;
  final firestore = FirebaseFirestore.instance;

  bool isLoading = false;

  Future<void> registerUser() async {

    if (nameController.text.isEmpty) {

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("الرجاء إدخال الاسم")),
      );
      return;
    }

    try {

      setState(() {
        isLoading = true;
      });

      String uid = auth.currentUser!.uid;

      await firestore.collection("users").doc(uid).update({

        "name": nameController.text,
        "phone": phoneController.text,
        "birthDate": birthDate?.toString(),
        "gender": gender ?? "ذكر",
        "education": education ?? "بكالوريوس",

      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("تم حفظ البيانات بنجاح")),
      );

      Navigator.pop(context);

    } catch (e) {

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );

    }

    setState(() {
      isLoading = false;
    });

  }

  Future<void> pickDate() async {

    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime(2000),
      firstDate: DateTime(1950),
      lastDate: DateTime.now(),
    );

    if (picked != null) {
      setState(() {
        birthDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(

        appBar: AppBar(
          title: const Text("إكمال البيانات"),
          backgroundColor: const Color(0xFF2563EB),
        ),

        body: Container(
          width: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFFF8FAFC),
                Color(0xFFF1F5F9),
                Color(0xFFEFF6FF),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),

          child: SingleChildScrollView(
            padding: const EdgeInsets.all(25),

            child: Container(
              padding: const EdgeInsets.all(25),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(25),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 20,
                  )
                ],
              ),

              child: Column(
                children: [

                  TextField(
                    controller: nameController,
                    decoration: InputDecoration(
                      labelText: "الاسم الكامل",
                      prefixIcon: const Icon(Icons.person),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                  ),

                  const SizedBox(height: 15),

                  TextField(
                    controller: phoneController,
                    decoration: InputDecoration(
                      labelText: "رقم الجوال ",
                      prefixIcon: const Icon(Icons.phone),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                  ),

                  const SizedBox(height: 15),

                  ListTile(
                    leading: const Icon(Icons.calendar_today),
                    title: Text(
                      birthDate == null
                          ? "اختر تاريخ الميلاد"
                          : birthDate.toString().split(" ")[0],
                    ),
                    onTap: pickDate,
                  ),

                  const SizedBox(height: 15),

                  DropdownButtonFormField(
                    hint: const Text("اختر الجنس"),
                    value: gender,
                    items: const [
                      DropdownMenuItem(
                        value: "ذكر",
                        child: Text("ذكر"),
                      ),
                      DropdownMenuItem(
                        value: "أنثى",
                        child: Text("أنثى"),
                      ),
                    ],
                    onChanged: (value) {
                      setState(() {
                        gender = value.toString();
                      });
                    },
                  ),

                  const SizedBox(height: 15),

                  DropdownButtonFormField(
                    hint: const Text("المستوى التعليمي"),
                    value: education,
                    items: const [
                      DropdownMenuItem(
                        value: "ثانوي",
                        child: Text("ثانوي"),
                      ),
                      DropdownMenuItem(
                        value: "دبلوم",
                        child: Text("دبلوم"),
                      ),
                      DropdownMenuItem(
                        value: "بكالوريوس",
                        child: Text("بكالوريوس"),
                      ),
                      DropdownMenuItem(
                        value: "ماجستير",
                        child: Text("ماجستير"),
                      ),
                    ],
                    onChanged: (value) {
                      setState(() {
                        education = value.toString();
                      });
                    },
                  ),

                  const SizedBox(height: 30),

                  SizedBox(
                    width: double.infinity,
                    height: 55,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF2563EB),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                      onPressed: isLoading ? null : registerUser,
                      child: isLoading
                          ? const CircularProgressIndicator(
                        color: Colors.white,
                      )
                          : const Text(
                        "انشاء حساب",
                        style: TextStyle(
                          fontSize: 18,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),

                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}