import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fl_chart/fl_chart.dart';
import 'manage_posts_screen.dart';
import 'manage_users_screen.dart';
import 'admin_profile_screen.dart';
import 'login_screen.dart';
import 'admin_reports_screen.dart';
import 'AdminManagementScreen.dart';

class AdminHomeScreen extends StatefulWidget {
  const AdminHomeScreen({super.key});

  @override
  State<AdminHomeScreen> createState() => _AdminHomeScreenState();
}

class _AdminHomeScreenState extends State<AdminHomeScreen> {
  int selectedIndex = 0;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  final List<String> titles = [
    "لوحة التحكم",
    "المنشورات التوعوية",
    "المستخدمين",
    "تقارير الفحص",
    "الملف الشخصي",
  ];


  int postsCount = 0;
  int usersCount = 0;
  int reportsCount = 0;

  Map<String, int> reportsPerDay = {};

  @override
  void initState() {
    super.initState();
    fetchCounts();
  }

  Future<void> fetchCounts() async {

    var postsSnap = await firestore.collection("posts").get();
    postsCount = postsSnap.docs.length;

    var usersSnap = await firestore.collection("users").get();
    usersCount = usersSnap.docs.length;

    var reportsSnap = await firestore.collection("scan_reports").get();
    reportsCount = reportsSnap.docs.length;

    reportsPerDay = {};
    for (var doc in reportsSnap.docs) {
      Timestamp t = doc['createdAt'];
      DateTime d = t.toDate();
      String key = "${d.day}/${d.month}";
      reportsPerDay[key] = (reportsPerDay[key] ?? 0) + 1;
    }

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text(titles[selectedIndex]),
          centerTitle: true,
        ),
        drawer: Drawer(
          child: Column(
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                color: const Color(0xFF2563EB),
                child: Column(
                  children: [
                    const SizedBox(height: 40),
                    // شعار بدل أيقونة الأدمن
                    SizedBox(
                      height: 100,
                      child: Image.asset(
                        "assets/logo.png", // ضع مسار شعارك هنا
                        fit: BoxFit.contain,
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      "لوحة تحكم المدير",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              menuItem(Icons.dashboard, "لوحة التحكم", 0),

              ListTile(
                leading: const Icon(Icons.article),
                title: const Text("المنشورات التوعوية"),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const ManagePostsScreen()),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.people),
                title: const Text("المستخدمين"),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const ManageUsersScreen()),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.people),
                title: const Text("ادارة المشرفين"),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const ManageAdminsScreen()),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.analytics),
                title: const Text("تقارير الفحص"),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const AdminReportsScreen()),
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.person),
                title: const Text("الملف الشخصي"),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const AdminProfileScreen()),
                  );
                },
              ),
              const Spacer(),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.logout, color: Colors.red),
                title: const Text("تسجيل الخروج"),
                onTap: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => const LoginScreen()),
                  );
                },
              )
            ],
          ),
        ),
        body: getPage(),
      ),
    );
  }

  Widget menuItem(IconData icon, String title, int index) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      selected: selectedIndex == index,
      selectedTileColor: Colors.blue.withOpacity(0.1),
      onTap: () {
        setState(() {
          selectedIndex = index;
        });
        Navigator.pop(context);
      },
    );
  }

  Widget getPage() {
    switch (selectedIndex) {
      case 0:
        return dashboardPage();
      default:
        return dashboardPage();
    }
  }

  Widget dashboardPage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          GridView.count(
            crossAxisCount: 2,
            crossAxisSpacing: 15,
            mainAxisSpacing: 15,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              dashboardCard(Icons.article, "المنشورات", Colors.green, postsCount),
              dashboardCard(Icons.people, "المستخدمين", Colors.orange, usersCount),
              dashboardCard(Icons.analytics, "عمليات الفحص", Colors.red, reportsCount),
            ],
          ),
          const SizedBox(height: 30),
          reportsPerDay.isEmpty
              ? const Text("لا توجد بيانات للرسم البياني")
              : SizedBox(
            height: 250,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: (reportsPerDay.values.isNotEmpty
                    ? (reportsPerDay.values.reduce((a, b) => a > b ? a : b))
                    : 0)
                    .toDouble() +
                    1,
                barTouchData: BarTouchData(enabled: true),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(showTitles: true),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        int index = value.toInt();
                        if (index < reportsPerDay.keys.length) {
                          return Text(reportsPerDay.keys.elementAt(index),
                              style: const TextStyle(fontSize: 12));
                        }
                        return const Text("");
                      },
                    ),
                  ),
                ),
                borderData: FlBorderData(show: false),
                barGroups: List.generate(reportsPerDay.length, (index) {
                  String key = reportsPerDay.keys.elementAt(index);
                  return BarChartGroupData(
                    x: index,
                    barRods: [
                      BarChartRodData(
                        toY: reportsPerDay[key]!.toDouble(),
                        color: Colors.blue,
                        width: 20,
                        borderRadius: BorderRadius.circular(4),
                      )
                    ],
                  );
                }),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget dashboardCard(IconData icon, String title, Color color, int count) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: color.withOpacity(0.1),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 50, color: color),
          const SizedBox(height: 10),
          Text(
            title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 5),
          Text(
            count.toString(),
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color),
          ),
        ],
      ),
    );
  }
}