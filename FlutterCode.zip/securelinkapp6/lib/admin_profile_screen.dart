import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AdminProfileScreen extends StatefulWidget {
  const AdminProfileScreen({super.key});

  @override
  State<AdminProfileScreen> createState() => _AdminProfileScreenState();
}

class _AdminProfileScreenState extends State<AdminProfileScreen> {
  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  final nameController = TextEditingController();
  final phoneController = TextEditingController();

  String gender = "ذكر";
  String education = "بكالوريوس";

  bool loading = true;

  /// ================== تحميل بيانات المستخدم ==================
  Future<void> loadUser() async {
    try {
      String uid = auth.currentUser!.uid;
      DocumentSnapshot doc = await firestore.collection('users').doc(uid).get();

      if (doc.exists) {
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;

        nameController.text = data.containsKey('name') ? (data['name'] ?? "") : "";
        phoneController.text = data.containsKey('phone') ? (data['phone'] ?? "") : "";

        String genderData = data.containsKey('gender') ? (data['gender'] ?? "Male") : "Male";
        gender = (genderData == "Male") ? "ذكر" : "أنثى";

        String educationData = data.containsKey('education') ? (data['education'] ?? "Bachelor") : "Bachelor";
        switch (educationData) {
          case "Secondary":
            education = "ثانوي";
            break;
          case "Bachelor":
            education = "بكالوريوس";
            break;
          case "Master":
            education = "ماجستير";
            break;
          case "PhD":
            education = "دكتوراه";
            break;
          default:
            education = "بكالوريوس";
        }
      }
    } catch (e) {
      print("Error loading admin profile: $e");
      nameController.text = "";
      phoneController.text = "";
      gender = "ذكر";
      education = "بكالوريوس";
    }

    setState(() {
      loading = false;
    });
  }

  /// ================== تحديث بيانات المستخدم ==================
  Future<void> updateProfile() async {
    try {
      String uid = auth.currentUser!.uid;

      // تحويل القيم العربية إلى القيم المخزنة في Firebase
      String genderValue = (gender == "ذكر") ? "Male" : "Female";
      String educationValue;
      switch (education) {
        case "ثانوي":
          educationValue = "Secondary";
          break;
        case "بكالوريوس":
          educationValue = "Bachelor";
          break;
        case "ماجستير":
          educationValue = "Master";
          break;
        case "دكتوراه":
          educationValue = "PhD";
          break;
        default:
          educationValue = "Bachelor";
      }

      await firestore.collection('users').doc(uid).update({
        "name": nameController.text.trim(),
        "phone": phoneController.text.trim(),
        "gender": genderValue,
        "education": educationValue,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("تم تحديث الملف الشخصي بنجاح")),
      );
    } catch (e) {
      print("Error updating admin profile: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("حدث خطأ أثناء التحديث")),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    loadUser();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("ملف الأدمن الشخصي"),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            /// صورة البروفايل
            const CircleAvatar(
              radius: 55,
              backgroundColor: Colors.blue,
              child: Icon(
                Icons.admin_panel_settings,
                color: Colors.white,
                size: 50,
              ),
            ),
            const SizedBox(height: 20),

            /// كارد البيانات
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  )
                ],
              ),
              child: Column(
                children: [
                  TextField(
                    controller: nameController,
                    decoration: const InputDecoration(
                      labelText: "الاسم",
                      prefixIcon: Icon(Icons.person),
                    ),
                  ),
                  const SizedBox(height: 15),
                  TextField(
                    controller: phoneController,
                    decoration: const InputDecoration(
                      labelText: "الهاتف",
                      prefixIcon: Icon(Icons.phone),
                    ),
                  ),
                  const SizedBox(height: 15),

                  DropdownButtonFormField(
                    value: gender,
                    decoration: const InputDecoration(
                      labelText: "الجنس",
                      prefixIcon: Icon(Icons.person_outline),
                    ),
                    items: const [
                      DropdownMenuItem(value: "ذكر", child: Text("ذكر")),
                      DropdownMenuItem(value: "أنثى", child: Text("أنثى")),
                    ],
                    onChanged: (value) {
                      setState(() {
                        gender = value!;
                      });
                    },
                  ),
                  const SizedBox(height: 15),

                  DropdownButtonFormField(
                    value: education,
                    decoration: const InputDecoration(
                      labelText: "المستوى التعليمي",
                      prefixIcon: Icon(Icons.school),
                    ),
                    items: const [
                      DropdownMenuItem(value: "ثانوي", child: Text("ثانوي")),
                      DropdownMenuItem(value: "بكالوريوس", child: Text("بكالوريوس")),
                      DropdownMenuItem(value: "ماجستير", child: Text("ماجستير")),
                      DropdownMenuItem(value: "دكتوراه", child: Text("دكتوراه")),
                    ],
                    onChanged: (value) {
                      setState(() {
                        education = value!;
                      });
                    },
                  ),
                  const SizedBox(height: 25),

                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: updateProfile,
                      child: const Text("تحديث الملف الشخصي"),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}