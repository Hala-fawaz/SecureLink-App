import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'user_reports_screen.dart';
import 'user_awareness_screen.dart';
import 'user_profile_screen.dart';
import 'login_screen.dart';

class UserHomeScreen extends StatefulWidget {
  const UserHomeScreen({super.key});

  @override
  State<UserHomeScreen> createState() => _UserHomeScreenState();
}

class _UserHomeScreenState extends State<UserHomeScreen> {
  int currentIndex = 0;
  bool isLoading = false; // متغير لحالة التحميل
  final TextEditingController urlController = TextEditingController();
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final FirebaseAuth auth = FirebaseAuth.instance;

  // دالة فحص الرابط والربط مع السحابة
  Future<void> scanLink() async {
    String url = urlController.text.trim();

    if (url.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("الرجاء إدخال الرابط أولاً")),
      );
      return;
    }

    setState(() {
      isLoading = true;
    });

    String result = "unknown";

    try {
      // الرابط الصحيح للسيرفر الخاص بك على Hugging Face
      final apiUrl = Uri.parse("https://rana1233-phishing-detection.hf.space/predict");

      final response = await http.post(
        apiUrl,
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: jsonEncode({"url": url}),
      ).timeout(const Duration(seconds: 90)); // تم زيادة المهلة إلى 90 ثانية لإعطاء السيرفر فرصة للاستيقاظ

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print("الرد من الموديل: $data");

        // قراءة النتيجة من الموديل بالشكل الصحيح بناءً على رد السيرفر الحالي
        var modelResult = data['result'];
        if (modelResult.toString() == "malicious" || modelResult.toString() == "phishing") {
          result = "malicious";
        } else if (modelResult.toString() == "safe") {
          result = "safe";
        }
      } else {
        print("خطأ في السيرفر: ${response.statusCode}");
      }
    } catch (e) {
      print("خطأ في الاتصال بالسحابة: $e");
    } finally {
      setState(() {
        isLoading = false;
      });
    }

    // حفظ التقرير في Firebase
    try {
      await firestore.collection("scan_reports").add({
        "url": url,
        "result": result,
        "userId": auth.currentUser?.uid ?? "anonymous",
        "createdAt": Timestamp.now(),
      });
    } catch (e) {
      print("خطأ في حفظ البيانات بـ Firebase: $e");
    }

    // عرض النتيجة للمستخدم
    _showResultDialog(result);
  }

  // دالة عرض نافذة النتيجة
  void _showResultDialog(String result) {
    IconData icon;
    Color color;
    String text;

    if (result == "safe") {
      icon = Icons.verified;
      color = Colors.green;
      text = "الرابط آمن ✅";
    } else if (result == "malicious") {
      icon = Icons.warning;
      color = Colors.red;
      text = "الرابط ضار ! ";
    } else {
      icon = Icons.help;
      color = Colors.orange;
      text = "تعذر الفحص، حاول مجدداً";
    }

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text("نتيجة الفحص الآلي", textAlign: TextAlign.center),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 70, color: color),
              const SizedBox(height: 15),
              Text(
                text,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
            ],
          ),
          actions: [
            Center(
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("حسناً", style: TextStyle(fontSize: 18)),
              ),
            )
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {List pages = [
    homePage(),
    reportsPage(),
    awarenessPage(),
    profilePage(),
  ];

  return Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text("SecureLink", style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        backgroundColor: const Color(0xFF2563EB),
        elevation: 0,
      ),
      body: pages[currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF2563EB),
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          setState(() {
            currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.search), label: "فحص"),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: "التقارير"),
          BottomNavigationBarItem(icon: Icon(Icons.security), label: "التوعية"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "حسابي"),
        ],
      ),
    ),
  );
  }

  Widget homePage() {
    return SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
          const Text(
          "مرحباً بك في SecureLink",
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        const Text(
          "قم بفحص أي رابط للتأكد من خلوه من التصيد أو البرمجيات الخبيثة",
          style: TextStyle(color: Colors.grey, fontSize: 16),
        ),
        const SizedBox(height: 30),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.08),
                blurRadius: 10,
                offset: const Offset(0, 5),
              )
            ],
          ),
          child: Column(
            children: [
              TextField(
                controller: urlController,
                decoration: InputDecoration(
                  hintText: "أدخل الرابط (مثال: http://example.com)",
                  prefixIcon: const Icon(Icons.link),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2563EB),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  onPressed: isLoading ? null : scanLink,
                  child: isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.search, color: Colors.white),
                      SizedBox(width: 10),
                      Text(
                        "فحص الرابط الآن",
                        style: TextStyle(fontSize: 18, color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 30),
        Container(padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.08),
                blurRadius: 10,
                offset: const Offset(0, 5),
              )
            ],
          ),
          child: const Row(
            children: [
              Icon(Icons.shield, color: Colors.green, size: 45),
              SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "نظام الحماية الذكي",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    SizedBox(height: 5),
                    Text(
                      "يستخدم هذا التطبيق موديل هجين يعتمد على AI لكشف التصيد.",
                      style: TextStyle(color: Colors.grey, fontSize: 14),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
          ],
        ),
    );
  }

  Widget reportsPage() => const UserReportsScreen();
  Widget awarenessPage() => const UserAwarenessScreen();
  Widget profilePage() => const UserProfileScreen();
}