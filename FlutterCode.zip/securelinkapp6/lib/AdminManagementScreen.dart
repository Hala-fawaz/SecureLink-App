import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ManageAdminsScreen extends StatefulWidget {
  const ManageAdminsScreen({super.key});

  @override
  State<ManageAdminsScreen> createState() => _ManageAdminsScreenState();
}

class _ManageAdminsScreenState extends State<ManageAdminsScreen> {

  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final FirebaseAuth auth = FirebaseAuth.instance;

  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  /// فتح الفورم
  void openForm({DocumentSnapshot? doc}) {

    if (doc != null) {

      passwordController.clear();

    } else {

      nameController.clear();
      emailController.clear();
      passwordController.clear();

    }

    showModalBottomSheet(

      context: context,

      isScrollControlled: true,

      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(25),
        ),
      ),

      builder: (context) {

        return Directionality(

          textDirection: TextDirection.rtl,

          child: Padding(

            padding: EdgeInsets.only(
              left: 20,
              right: 20,
              top: 25,
              bottom: MediaQuery.of(context).viewInsets.bottom + 20,
            ),

            child: SingleChildScrollView(

              child: Column(

                children: [

                  Text(

                    doc == null
                        ? "إضافة أدمن"
                        : "تغيير كلمة المرور",

                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),

                  ),

                  const SizedBox(height: 20),

                  /// يظهر فقط عند الإضافة
                  if (doc == null) ...[

                    TextField(

                      controller: nameController,

                      decoration: const InputDecoration(
                        labelText: "الاسم",
                        prefixIcon: Icon(Icons.person),
                        border: OutlineInputBorder(),
                      ),

                    ),

                    const SizedBox(height: 15),

                    TextField(

                      controller: emailController,

                      decoration: const InputDecoration(
                        labelText: "البريد الإلكتروني",
                        prefixIcon: Icon(Icons.email),
                        border: OutlineInputBorder(),
                      ),

                    ),

                    const SizedBox(height: 15),

                  ],

                  /// كلمة المرور
                  TextField(

                    controller: passwordController,

                    obscureText: true,

                    decoration: InputDecoration(

                      labelText:
                      doc == null
                          ? "كلمة المرور"
                          : "كلمة المرور الجديدة",

                      prefixIcon: const Icon(Icons.lock),

                      border: const OutlineInputBorder(),

                    ),

                  ),

                  if (doc != null)

                    const Padding(

                      padding: EdgeInsets.only(top: 10),

                      child: Text(
                        "يمكن تغيير كلمة المرور فقط",
                        style: TextStyle(color: Colors.grey),
                      ),

                    ),

                  const SizedBox(height: 25),

                  SizedBox(

                    width: double.infinity,

                    child: ElevatedButton(

                      onPressed: () async {

                        try {

                          if (doc == null) {

                            /// إضافة أدمن جديد

                            UserCredential userCredential =
                            await auth.createUserWithEmailAndPassword(

                              email: emailController.text.trim(),

                              password:
                              passwordController.text.trim(),

                            );

                            String uid =
                                userCredential.user!.uid;

                            await firestore
                                .collection('users')
                                .doc(uid)
                                .set({

                              "name":
                              nameController.text.trim(),

                              "email":
                              emailController.text.trim(),

                              "isAdmin": true,

                              "createdAt":
                              Timestamp.now(),

                              "phone": "",

                              "gender": "",

                              "education": "",

                              "birthDate": "",

                            });

                            ScaffoldMessenger.of(context)
                                .showSnackBar(

                              const SnackBar(
                                content:
                                Text("تم إضافة الأدمن"),
                              ),

                            );

                          } else {

                            /// تغيير كلمة المرور

                            if (passwordController
                                .text
                                .trim()
                                .isNotEmpty) {

                              await auth.currentUser!
                                  .updatePassword(
                                passwordController.text.trim(),
                              );

                              ScaffoldMessenger.of(context)
                                  .showSnackBar(

                                const SnackBar(
                                  content: Text(
                                    "تم تغيير كلمة المرور",
                                  ),
                                ),

                              );

                            }

                          }

                          Navigator.pop(context);

                        } catch (e) {

                          ScaffoldMessenger.of(context)
                              .showSnackBar(

                            SnackBar(
                              content: Text(e.toString()),
                            ),

                          );

                        }

                      },

                      child: Text(
                        doc == null
                            ? "إضافة"
                            : "تحديث",
                      ),

                    ),

                  ),

                  const SizedBox(height: 20),

                ],

              ),

            ),

          ),

        );

      },

    );

  }

  @override
  Widget build(BuildContext context) {

    return Directionality(

      textDirection: TextDirection.rtl,

      child: Scaffold(

        appBar: AppBar(

          title: const Text("إدارة الأدمن"),

          centerTitle: true,

        ),

        floatingActionButton: FloatingActionButton(

          onPressed: () => openForm(),

          child: const Icon(Icons.add),

        ),

        body: StreamBuilder<QuerySnapshot>(

          stream: firestore
              .collection('users')
              .where('isAdmin', isEqualTo: true)
              .snapshots(),

          builder: (context, snapshot) {

            if (!snapshot.hasData) {

              return const Center(
                child: CircularProgressIndicator(),
              );

            }

            var docs = snapshot.data!.docs;

            docs.sort((a, b) {

              Timestamp aTime =
                  a['createdAt'] ?? Timestamp.now();

              Timestamp bTime =
                  b['createdAt'] ?? Timestamp.now();

              return bTime.compareTo(aTime);

            });

            if (docs.isEmpty) {

              return const Center(
                child: Text("لا يوجد أدمن"),
              );

            }

            return ListView.builder(

              padding: const EdgeInsets.all(15),

              itemCount: docs.length,

              itemBuilder: (context, index) {

                var doc = docs[index];

                Map<String, dynamic> data =
                doc.data() as Map<String, dynamic>;

                String name = data["name"] ?? "";
                String email = data["email"] ?? "";

                return Container(

                  margin:
                  const EdgeInsets.only(bottom: 15),

                  decoration: BoxDecoration(

                    color: Colors.white,

                    borderRadius:
                    BorderRadius.circular(20),

                    boxShadow: [

                      BoxShadow(

                        color:
                        Colors.black.withOpacity(0.08),

                        blurRadius: 10,

                        offset: const Offset(0, 5),

                      )

                    ],

                  ),

                  child: ListTile(

                    leading: const CircleAvatar(

                      radius: 28,

                      backgroundColor: Colors.red,

                      child: Icon(
                        Icons.admin_panel_settings,
                        color: Colors.white,
                      ),

                    ),

                    title: Text(

                      name,

                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                      ),

                    ),

                    subtitle: Text(email),

                    trailing: IconButton(

                      icon: const Icon(
                        Icons.edit,
                        color: Colors.blue,
                      ),

                      onPressed: () => openForm(doc: doc),

                    ),

                  ),

                );

              },

            );

          },

        ),

      ),

    );

  }

}