import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UserReportsScreen extends StatelessWidget {
  const UserReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {

    final FirebaseFirestore firestore = FirebaseFirestore.instance;
    final FirebaseAuth auth = FirebaseAuth.instance;

    return Directionality(
      textDirection: TextDirection.rtl,

      child: StreamBuilder<QuerySnapshot>(

        stream: firestore
            .collection("scan_reports")
            .where("userId", isEqualTo: auth.currentUser!.uid)
            .snapshots(),

        builder: (context, snapshot) {

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(
              child: Text(
                "لا توجد تقارير فحص حتى الآن",
                style: TextStyle(fontSize: 18),
              ),
            );
          }

          var reports = snapshot.data!.docs;

          /// ترتيب التقارير حسب التاريخ

          reports.sort((a, b) {
            Timestamp aTime = a['createdAt'];
            Timestamp bTime = b['createdAt'];
            return bTime.compareTo(aTime);
          });

          return ListView.builder(

            padding: const EdgeInsets.all(20),

            itemCount: reports.length,

            itemBuilder: (context, index) {

              var report = reports[index];

              String url = report['url'];
              String result = report['result'];

              Timestamp time = report['createdAt'];
              DateTime date = time.toDate();

              IconData icon;
              Color color;
              String text;

              if (result == "safe") {
                icon = Icons.verified;
                color = Colors.green;
                text = "الرابط آمن";
              } else if (result == "malicious") {
                icon = Icons.warning;
                color = Colors.red;
                text = "رابط خطير";
              } else {
                icon = Icons.help_outline;
                color = Colors.orange;
                text = "غير معروف";
              }

              return Container(

                margin: const EdgeInsets.only(bottom: 15),

                padding: const EdgeInsets.all(18),

                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.06),
                      blurRadius: 10,
                      offset: const Offset(0,4),
                    )
                  ],
                ),

                child: Row(
                  children: [

                    /// أيقونة النتيجة

                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: color.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(icon, color: color, size: 30),
                    ),

                    const SizedBox(width: 15),

                    /// معلومات التقرير

                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                          Text(
                            url,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          const SizedBox(height: 6),

                          Text(
                            text,
                            style: TextStyle(
                              color: color,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          const SizedBox(height: 4),

                          Text(
                            "${date.day}/${date.month}/${date.year}",
                            style: const TextStyle(
                              color: Colors.grey,
                              fontSize: 12,
                            ),
                          ),

                        ],
                      ),
                    ),

                  ],
                ),

              );

            },

          );

        },

      ),
    );

  }

}