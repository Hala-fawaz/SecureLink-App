import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AdminReportsScreen extends StatelessWidget {
  const AdminReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final FirebaseFirestore firestore = FirebaseFirestore.instance;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      appBar: AppBar(
        title: const Text("تقارير الفحص"),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: firestore
            .collection("scan_reports")
            .orderBy("createdAt", descending: true)
            .snapshots(),
        builder: (context, reportSnapshot) {
          if (reportSnapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!reportSnapshot.hasData || reportSnapshot.data!.docs.isEmpty) {
            return const Center(
              child: Text(
                "لا توجد تقارير حتى الآن",
                style: TextStyle(fontSize: 18),
              ),
            );
          }

          final reports = reportSnapshot.data!.docs;

          // جلب كل المستخدمين مرة واحدة لتسريع الأداء
          return StreamBuilder<QuerySnapshot>(
            stream: firestore.collection("users").snapshots(),
            builder: (context, userSnapshot) {
              if (!userSnapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final users = {
                for (var u in userSnapshot.data!.docs) u.id: u
              };

              return ListView.builder(
                padding: const EdgeInsets.all(20),
                itemCount: reports.length,
                itemBuilder: (context, index) {
                  final report = reports[index];

                  String url = report['url'];
                  String result = report['result'];
                  String userId = report['userId'];

                  Timestamp time = report['createdAt'];
                  DateTime date = time.toDate();

                  IconData icon;
                  Color color;

                  if (result == "safe") {
                    icon = Icons.verified;
                    color = Colors.green;
                  } else if (result == "malicious") {
                    icon = Icons.warning;
                    color = Colors.red;
                  } else {
                    icon = Icons.help;
                    color = Colors.orange;
                  }

                  // بيانات المستخدم
                  final user = users[userId];
                  final name = user != null ? user['name'] : "مستخدم غير معروف";
                  final email = user != null ? user['email'] : "";

                  return Container(
                    margin: const EdgeInsets.only(bottom: 15),
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 10,
                          offset: const Offset(0, 5),
                        )
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // معلومات المستخدم
                        Row(
                          children: [
                            const CircleAvatar(
                              radius: 22,
                              backgroundColor: Color(0xFF2F6BFF),
                              child: Icon(Icons.person, color: Colors.white),
                            ),
                            const SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  name,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                                Text(
                                  email,
                                  style: const TextStyle(
                                    color: Colors.grey,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 15),
                        // الرابط
                        Text(
                          "الرابط: $url",
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                          ),
                        ),
                        const SizedBox(height: 12),
                        // النتيجة + التاريخ
                        Row(
                          children: [
                            Icon(icon, color: color),
                            const SizedBox(width: 6),
                            Text(
                              "الحالة: ${result.toUpperCase()}",
                              style: TextStyle(
                                color: color,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const Spacer(),
                            Text(
                              "${date.day}/${date.month}/${date.year}",
                              style: const TextStyle(
                                color: Colors.grey,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}