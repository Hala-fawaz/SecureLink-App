import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_app_check/firebase_app_check.dart';

import 'welcome_screen.dart';

void main() async {

  WidgetsFlutterBinding.ensureInitialized();

  /// تشغيل Firebase
  await Firebase.initializeApp();

  /// تفعيل Firebase App Check
  await FirebaseAppCheck.instance.activate(

    /// أثناء التطوير
    androidProvider: AndroidProvider.debug,

  );

  runApp(const SecureLinkApp());

}

class SecureLinkApp extends StatelessWidget {

 
  const SecureLinkApp({super.key});

  @override
  Widget build(BuildContext context) {

    return MaterialApp(

      debugShowCheckedModeBanner: false,

      title: 'SecureLink App',

      theme: ThemeData(

        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2F6BFF),
        ),

        useMaterial3: true,

      ),

      home: const WelcomeScreen(),

    );

  }

}