import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {

  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;

  final nameController = TextEditingController();
  final phoneController = TextEditingController();

  String? gender;
  String? education;

  bool loading = true;

  /// تحميل بيانات المستخدم
  Future loadUser() async {

    String uid = auth.currentUser!.uid;

    var doc = await firestore.collection("users").doc(uid).get();
    var data = doc.data() ?? {};

    nameController.text = data["name"] ?? "";
    phoneController.text = data["phone"] ?? "";

    gender = (data["gender"] == null || data["gender"] == "")
        ? "ذكر"
        : data["gender"];

    education = (data["education"] == null || data["education"] == "")
        ? "بكالوريوس"
        : data["education"];

    setState(() {
      loading = false;
    });

  }

  /// تحديث البيانات
  Future updateProfile() async {

    try {

      String uid = auth.currentUser!.uid;

      await firestore.collection("users").doc(uid).update({

        "name": nameController.text,
        "phone": phoneController.text,
        "gender": gender,
        "education": education,

      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("تم تحديث البيانات بنجاح")),
      );

    } catch (e) {

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );

    }

  }

  @override
  void initState() {
    super.initState();
    loadUser();
  }

  @override
  Widget build(BuildContext context) {

    if (loading) {
      return const Center(child: CircularProgressIndicator());
    }

    return Directionality(
      textDirection: TextDirection.rtl,

      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),

        child: Column(
          children: [

            const CircleAvatar(
              radius: 50,
              backgroundColor: Color(0xFF2563EB),
              child: Icon(
                Icons.person,
                size: 50,
                color: Colors.white,
              ),
            ),

            const SizedBox(height: 25),

            /// تعديل البيانات
            buildCard(
              child: Column(
                children: [

                  TextField(
                    controller: nameController,
                    decoration: const InputDecoration(
                      labelText: "الاسم",
                      prefixIcon: Icon(Icons.person),
                    ),
                  ),

                  const SizedBox(height: 15),

                  TextField(
                    controller: phoneController,
                    decoration: const InputDecoration(
                      labelText: "رقم الجوال",
                      prefixIcon: Icon(Icons.phone),
                    ),
                  ),

                  const SizedBox(height: 15),

                  /// الجنس
                  DropdownButtonFormField<String>(

                    value: ["ذكر", "أنثى"].contains(gender)
                        ? gender
                        : null,

                    decoration: const InputDecoration(
                      labelText: "الجنس",
                      prefixIcon: Icon(Icons.people),
                    ),

                    items: const [

                      DropdownMenuItem(
                        value: "ذكر",
                        child: Text("ذكر"),
                      ),

                      DropdownMenuItem(
                        value: "أنثى",
                        child: Text("أنثى"),
                      ),

                    ],

                    onChanged: (value){
                      setState(() {
                        gender = value!;
                      });
                    },

                  ),

                  const SizedBox(height: 15),

                  /// المستوى التعليمي
                  DropdownButtonFormField<String>(

                    value: ["ثانوي", "بكالوريوس", "ماجستير", "دكتوراه"]
                        .contains(education)
                        ? education
                        : null,

                    decoration: const InputDecoration(
                      labelText: "المستوى التعليمي",
                      prefixIcon: Icon(Icons.school),
                    ),

                    items: const [

                      DropdownMenuItem(
                        value: "ثانوي",
                        child: Text("ثانوي"),
                      ),

                      DropdownMenuItem(
                        value: "بكالوريوس",
                        child: Text("بكالوريوس"),
                      ),

                      DropdownMenuItem(
                        value: "ماجستير",
                        child: Text("ماجستير"),
                      ),

                      DropdownMenuItem(
                        value: "دكتوراه",
                        child: Text("دكتوراه"),
                      ),

                    ],

                    onChanged: (value){
                      setState(() {
                        education = value!;
                      });
                    },

                  ),

                  const SizedBox(height: 25),

                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: updateProfile,
                      child: const Text("تحديث البيانات"),
                    ),
                  ),

                ],
              ),
            ),

          ],
        ),
      ),
    );

  }

  /// تصميم الكروت
  Widget buildCard({required Widget child}) {

    return Container(

      padding: const EdgeInsets.all(20),

      decoration: BoxDecoration(

        color: Colors.white,

        borderRadius: BorderRadius.circular(20),

        boxShadow: [

          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
          )

        ],
      ),

      child: child,

    );

  }

}