package com.example.securelinkapp3

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
